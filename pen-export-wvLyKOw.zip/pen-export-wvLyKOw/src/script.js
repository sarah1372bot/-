// اجرای کد بعد از بارگذاری کامل صفحه
document.addEventListener('DOMContentLoaded', () => {
    console.log('سایت داروسازی بارگذاری شد!');

    // نمونه‌ای از تغییر رنگ پس‌زمینه بخش‌ها در هنگام کلیک
    const sections = document.querySelectorAll('section');
    sections.forEach(section => {
        section.addEventListener('click', () => {
            section.style.backgroundColor = '#dcedc8'; // تغییر رنگ پس‌زمینه به سبز روشن
        });
    });

    // نمونه‌ای از نمایش پیغام خوشامدگویی
    const welcomeMessage = document.createElement('div');
    welcomeMessage.textContent = 'خوش آمدید به سایت آموزش داروسازی!';
    welcomeMessage.style.position = 'fixed';
    welcomeMessage.style.top = '10px';
    welcomeMessage.style.left = '10px';
    wel
